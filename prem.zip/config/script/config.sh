#!/bin/bash
##Dababase Server
HOST='95.216.112.32'
USER='migilase_migi'
PASS='migila0987654321'
DB='migilase_migi'
PORT='3306'